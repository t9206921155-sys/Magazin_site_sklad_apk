# Блок 28 — Установка «из коробки»: авторазвёртывание, Telegram и приложения

**Статус:** ✅ выполнен 12.09.2026
**Сессия:** 12.09.2026
**Зависит от:** блоки 12, 15 (smoke, security) — выполнены
**Оценка:** одна сессия

---

## Цель

Убрать последний ручной барьер: установка, развёртывание на VPS,
настройка Telegram-магазина и сборка мобильных приложений — скриптами,
одной командой, с валидацией и без секретов в выводе/логах.

## Контекст

- **Было:** `install.sh` (только deps + копия `.env.example` + запуск),
  `bootstrap-vps.sh`/`auto-deploy-vps.sh` с жёстким требованием вручную
  заполнить `.env` (иначе exit 2/1), сборка APK только через CI или
  ручной вызов двух скриптов с URL, настройка бота — только стартом
  всего сервера, `deploy.sh`/`post_deploy_smoke_check.sh` с устаревшей
  версией 1.0.6, `build-distr.sh` с захардкоженной проверкой 1.1.0.
- Бот уже самонастраивается при старте (`bot.py`: webhook/polling,
  кнопка меню), БД создаётся автоматически (`CREATE TABLE IF NOT EXISTS`)
  — не хватало именно оркестрации «из коробки».

## Задачи

- [x] `setup.sh` — единая точка входа: local / --vps / --update /
      --setup-bot / --build-apps / --check / --dry-run
- [x] `deploy/setup-env.sh` — мастер `.env`: интерактив + `SETUP_*`/флаги,
      валидация, генерация секретов, маскировка, `chmod 600`, `--check`
- [x] `telegram-shop/scripts/setup_bot.py` (только stdlib): getMe,
      setMyCommands (7 реальных команд), кнопка меню, webhook/polling,
      тест админам; `--dry-run` без сети
- [x] `deploy/build-apps.sh` — сборка «Склада» и «Магазина» с URL,
      проверка артефактов, deep links, QR, сверка версий с сервером
- [x] `deploy/update.sh` — безопасное обновление: бэкап БД + ротация 7,
      делегирование `auto-deploy-vps.sh`
- [x] `bootstrap-vps.sh` — переписан: мастер вместо exit 2, swap для
      слабых VPS (требование блока 18), ufw-подсказка, таймеры
      бэкапа/ротации/watchdog, итоговая сводка
- [x] Мелкие фиксы: версия 1.0.6→1.1.0 в `deploy.sh` и smoke-скрипте;
      параметризованная самопроверка `build-distr.sh` (+ `setup.sh`,
      `SETUP-AUTO.md` в составе архива)
- [x] Тесты `tests/test_setup_scripts.py` — 19 шт., офлайн, без sudo
- [x] Документация: `SETUP-AUTO.md`, этот отчёт, ROADMAP, README

## Критерии приёмки

- [x] `./setup.sh --dry-run` и все `--help` работают без изменений
- [x] Мастер генерирует все 18 ключей `.env`, маскирует секреты, `chmod 600`
- [x] Невалидный токен/ID/оплата/режим отклоняются с понятной ошибкой
- [x] `setup_bot.py --dry-run` показывает план; команды сверены с `bot.py` тестом
- [x] `build-apps.sh --dry-run` планирует обе сборки; плохие URL/флаги отклоняются
- [x] `pytest tests/` зелёный (35/35: 16 старых + 19 новых)
- [x] `bash -n` по всем затронутым скриптам — чисто
- [x] Боевой `.env` тестами не трогается (`SETUP_ENV_FILE` во временные файлы)

## Отчёт (12.09.2026)

### Что сделано

Новые файлы: `setup.sh`, `deploy/setup-env.sh`, `deploy/build-apps.sh`,
`deploy/update.sh`, `telegram-shop/scripts/setup_bot.py`,
`tests/test_setup_scripts.py`, `SETUP-AUTO.md`, этот файл.
Изменены: `deploy/bootstrap-vps.sh` (переписан с сохранением интерфейса
переменных), `deploy/deploy.sh`, `telegram-shop/scripts/post_deploy_smoke_check.sh`,
`build-distr.sh`, `README.md`, `ROADMAP.md`.

Проверено живой демонстрацией: генерация `.env` во временный файл →
`--check` → `setup_bot.py --dry-run` (getMe, 7 команд, кнопка меню,
webhook/polling, тест админам) — вывод корректен, токен замаскирован.

### Регрессия 12.09.2026

`pytest tests/`: 35/35 ✅ (включая 19 новых). Полный `run-tests.sh` —
зелёный ✅ (health 2, storage-contracts 32, labels 20, hid 8, stage5 23,
block06 33, block09 47, block14 32, block25 29, block27 86, pytest 35,
env-keys 18; сборки APK пропущены вне CI).

Дополнительно (синхронизация 12.09.2026, «от себя»): корневой `pytest tests/`
встроен в `run-tests.sh` и CI (`requirements-dev.txt` + `pytest>=7`,
workflow ставит dev-зависимости); PDF-руководство актуализировано
(§3.1 setup.sh, §3.4 новый bootstrap, §9 «Магазин», §15 update/CI) и
пересобрано; `distr/Telegram-Shop-1.1.0.zip` пересобран со всеми файлами
блока 28; счётчики ROADMAP обновлены (pytest 35, ~480 проверок).

### Ручные шаги владельца

Никаких новых. Следующие ручные шаги — из блоков 11/17/18/22, теперь
с опорой на `./setup.sh --vps` и `SETUP-AUTO.md` вместо ручного `.env`.

### Известные ограничения

- Сборка APK локально требует ~500 МБ (JDK+SDK в `~/.cache`) и сети;
  в CI собирается автоматически.
- `setup_bot.py` не заменяет runtime-настройку бота, а дублирует её для
  проверки до старта сервера (by design).
- HTTPS на VPS требует DNS на сервер и email для certbot; без них —
  предупреждение и пропуск (`SETUP_SKIP_HTTPS=1` явно).
