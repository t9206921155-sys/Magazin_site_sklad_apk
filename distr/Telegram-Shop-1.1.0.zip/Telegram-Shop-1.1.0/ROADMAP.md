# 🗺 ROADMAP — единый трекер состояния проекта

> **Это главный файл проекта.** Любая новая сессия начинается с его чтения.
> Здесь и только здесь фиксируется, какой блок выполнен, а какой нет.
>
> Обновлено: 04.09.2026 · Репозиторий: `t9206921155-sys/Magazin_site_sklad_apk`

---

## ⚡ Быстрый старт новой сессии

Полный клон репозитория весит **106 МБ** и не помещается в песочницу.
Работать нужно с лёгким клоном — **7 МБ** вместо 106:

```bash
git clone --depth 1 --filter=blob:none --sparse \
  https://github.com/t9206921155-sys/Magazin_site_sklad_apk.git repo
cd repo
git sparse-checkout set --no-cone '/*' \
  '!telegram-shop/screenshots' '!telegram-shop/apk' '!telegram-shop/aab'
```

Подробности и проверенные команды — в **`SESSION-PLAYBOOK.md`**.
План конкретного блока — в `blocks/BLOCK-XX-*.md`.

---

## 📊 Состояние блоков

Легенда: ✅ выполнено · 🔨 в работе · ⏳ запланировано · ⛔ заблокировано

| # | Блок | Статус | Сессия | Файл плана |
|---|---|---|---|---|
| 00 | Инфраструктура сессий (этот трекер, playbook, блоки) | ✅ | 04.09.2026 | — |
| 01 | Аудит связности UI↔API, удаление товара | ✅ | 03.09.2026 | `blocks/BLOCK-01-audit-fixes.md` |
| 02 | Сканер: HID Bluetooth/ТСД | ✅ | 03.09.2026 | `blocks/BLOCK-02-scanner.md` |
| 03 | Печать: наклейки, ZPL/EPL, ценники | ✅ | 04.09.2026 | `blocks/BLOCK-03-printing.md` |
| 04 | Офлайн-режим и обмен с 1С | ✅ | 04.09.2026 | `blocks/BLOCK-04-offline-1c.md` |
| 05 | Гигиена репозитория (−22 МБ скринов) | ✅ | 04.09.2026 | `blocks/BLOCK-05-repo-hygiene.md` |
| 06 | Мультисклад и роли (API) | ✅ | 04.09.2026 | `blocks/BLOCK-06-multiwarehouse.md` |
| 06a | Мультисклад: интерфейс | ✅ | 04.09.2026 | `blocks/BLOCK-06a-multiwarehouse-ui.md` |
| 07 | Отчёты по оборачиваемости | ✅ | 04.09.2026 | `blocks/BLOCK-07-reports.md` |
| 08 | Прямая печать на IP-принтер (ZPL по сети) | ✅ | 04.09.2026 | `blocks/BLOCK-08-network-printing.md` |
| 09 | Маркетплейс: каталог, поиск, фильтры | ✅ | 08.09.2026 | `blocks/BLOCK-09-marketplace-catalog.md` |
| 10 | Тесты и CI | ✅ | 04.09.2026 | `blocks/BLOCK-10-tests-ci.md` |
| 11 | Проверка на реальном железе | ⛔ | — | `blocks/BLOCK-11-hardware.md` |

**Вся кодовая часть проекта закрыта: 20 из 24 блоков.** Остались только внешние:
**11** (реальное железо, ⛔), **17** (ручная staging-валидация), **18** (backup на
тестовом VPS), **22** (официальный API-аудит Wildberries, ⛔).
Регрессию запускать в порядке: labels → hid → stage5 → block06 → block09 → block13
→ block14 → block16 → block19 → block23 → pytest → **block15 (последним — ставит IP
в rate-карантин ~60с)**.

---

## ✅ Что уже работает

### Ядро
- FastAPI + SQLite, ~150 эндпоинтов, `api.py` ~3.5 тыс. строк, `store.py` ~3 тыс.
- Сайт SSR (`/`, `/catalog`, `/p/{id}`), SPA-корзина (`/shop`), Mini App (`/app`),
  админка (`/admin`), склад-PWA (`/warehouse/`).
- APK и AAB `Sklad-1.1.0` (пакет `ru.telegramshop.sklad`) и покупательское
  приложение `Shop-1.0.0` (пакет `ru.telegramshop.shop`, блок 25 Ф1:
  `mobile/android-wrapper/`, страница `/download/app`, `GET /api/app/version`),
  1С-расширение.
- **CSP (блок 27)**: весь inline-JS публичного сайта вынесен в `/site/js/*.js`;
  строгий `Content-Security-Policy` (`script-src 'self'`) на SSR-страницах,
  Report-Only на внутренних инструментах (`/app`, `/warehouse`, `/admin`, `/crm`, `/shop`).

### Склад
- Товары, фото до 20 шт, артикулы, места хранения, владельцы.
- Роли админ/сотрудник, журнал операций, PIN и биометрия (WebAuthn).
- Сканирование: камера, ИИ-vision, **HID Bluetooth/ТСД**, инвентаризация со сверкой.
- Печать: PDF-наклейки (Code128 + QR), ZPL (Zebra), EPL (Eltron), **ценники для зала**.
- Облако: 3 режима — `vps`, `supabase_proxy`, `supabase_direct`; S3/Supabase/MySQL.
- **Офлайн-режим**: network-first для API, очередь операций в IndexedDB, Background Sync.
- **Мультисклад**: несколько складов, остатки по каждому, перемещение, доступы сотрудников
  (API готов; селектор в UI — блок 06a).

### Обмен с 1С
`GET/POST /1c/catalog`, **`GET/POST /1c/stock`**, `GET /1c/orders`,
`POST /1c/orders/ack`, `POST /1c/orders/status`.

### Тесты — 100+ автотестов, все проходят
```bash
cd telegram-shop
python3 tests-labels.py       # 20 — этикетки и ценники
node tests-hid-scanner.js     #  8 — HID-парсер
python3 tests-stage5.py       # 23 — 1С и офлайн (нужен запущенный сервер)
python3 tests-block06.py      # 33 — мультисклад (нужен запущенный сервер)
python3 tests-block09.py      # 47 — каталог и фильтры (нужен запущенный сервер)
python3 tests-storage-contracts.py  # 32 — контракты storage-провайдеров (офлайн)
python3 tests-block13.py      # 33 — storage layer: маскирование, диагностика (нужен сервер)
python3 tests-block14.py      # 32 — backup/restore, миграция SQLite→MySQL (нужен сервер)
python3 tests-block16.py      # 45 — подписки, брони, жалобы, бусты (нужен сервер)
python3 tests-block19.py      # 19 — CRM: задачи, чат, права (нужен сервер)
python3 tests-block23.py      # 20 — content-jobs и fallback-слайдшоу (нужен сервер)
python3 tests-block15.py      # 40 — security/observability (нужен сервер; ЗАПУСКАТЬ ПОСЛЕДНИМ)
pytest tests/                 # 16 — маркетинг/SEO/провайдеры (из корня репо)
```

---

## 🐛 Исправленные баги (чтобы не искать заново)

| Баг | Симптом | Блок |
|---|---|---|
| Удаление товара | Эндпоинта не было (405), UI звал админский маршрут (403) | 01 |
| HID-парсер | Мёртвая ветка, склейка кодов, двойное списание в режиме «Продажа» | 02 |
| ZPL-инъекция | `^XZ` в названии рвал этикетку, `~JA` отменял все задания печати | 03 |
| Печать из UI | `window.open` не слал токен — всегда 403 | 03 |
| Service worker | cache-first на API: склад показывал устаревшие остатки, кэшировал ключи | 04 |
| Обмен с 1С | Нельзя обновить только остатки — требовался полный каталог | 04 |
| Новый товар вне мультисклада | `add_product` не писал в `wh_stock` — разбивка пустая, перемещение падало | 06 |
| SSR-каталог 500 | Свободные имена `price_min/sort/...` в `_render_catalog` — NameError, `/catalog` лежал целиком | 09 |
| Фильтр «только с торгом» | У товара не было поля `negotiable` (проверялся несуществующий ключ) — фильтр не влиял на выдачу | 09 |
| `sort=rating`-заглушка | Сортировал по несуществующему `seller_rating` товара; теперь рейтинг продавца из `store.seller_rating` | 09 |
| Утечка YD OAuth-токена | `GET /api/warehouse/settings` отдавал `yandex_disk_token` в открытом виде (в т.ч. роли worker) | 13 |
| Неизвестные secret-поля в настройках | PUT мерджил произвольные поля — секрет с неизвестным именем возвращался клиенту без маскировки; теперь allowlist + динамическая маскировка | 13 |

---

## ⚠️ Известные ограничения

- **Цены — целые рубли.** `int(...)` сквозной по проекту (заказы, комиссии,
  выплаты). Копейки поддержаны в форматтере этикеток, но из БД приходит целое.
  Смена типа = миграция БД, отдельная задача.
- **`.git` весит 74 МБ** — история хранит удалённые картинки. Чистится только
  через `git filter-repo` с перезаписью истории и force-push (ломает все клоны).
  Обходится sparse-клоном, см. playbook.
- **Флаги `chmod +x` слетают** при работе агента — проверять перед коммитом.
- **Background Sync не работает в Safari/iOS** — там очередь уходит при
  следующем открытии приложения (фолбэк на событие `online`).

---

## 🔑 Доступы

- Склад: `admin` / `ADMIN_PASSWORD` из `.env` (по умолчанию `admin123`).
- Токен 1С: `store.settings["1c_token"]`, перевыпуск в админке.
- **GitHub-токен из истории чата скомпрометирован — отозвать и выпустить новый.**

---

## 📁 Куда что писать

```
ROADMAP.md              ← этот файл: статусы блоков (обновлять каждую сессию)
SESSION-PLAYBOOK.md     ← как поднять окружение и синхронизироваться
blocks/BLOCK-XX-*.md    ← план и отчёт по каждому блоку
telegram-shop/tests-*   ← автотесты
```

---

## 🧭 Следующий трек: production hardening и развитие платформы

После блока 10 дальнейшая работа идёт по отдельному треку. Каждый блок имеет свой план и отчёт; новая сессия начинает с первого блока со статусом ⏳.

| # | Блок | Статус | Зависит от | Файл плана |
|---|---|---|---|---|
| 12 | Production health-check и post-deploy smoke | ✅ | 10 | `blocks/BLOCK-12-production-smoke.md` |
| 13 | Единый storage layer и конфигурация провайдеров | ✅ | 08.09.2026 | `blocks/BLOCK-13-storage-layer.md` |
| 14 | Backup, restore и миграция MySQL/MariaDB | ✅ | 08.09.2026 | `blocks/BLOCK-14-backup-mysql.md` |
| 15 | Production security и observability | ✅ | 08.09.2026 | `blocks/BLOCK-15-security-observability.md` |
| 16 | Marketplace 2.0: продавцы, сделки и доверие | ✅ | 08.09.2026 | `blocks/BLOCK-16-marketplace-2.md` |

**Правило продолжения:** новая сессия читает `ROADMAP.md`, `SESSION-PLAYBOOK.md` и первый незакрытый файл блока из этого трека. Не начинать следующий блок до заполнения отчёта и push текущего.

**Состояние трека (12.09.2026):** кодовые блоки 13–16, 19–21, 23–25(Ф1), 26–28 закрыты.
Остались блоки с внешними зависимостями: **11** (реальное железо), **17** (ручная
staging-валидация по `DEVELOPER-MANUAL-VALIDATION.md`), **18** (backup на тестовом
VPS), **22** (ждёт официальный API-аудит Wildberries), **25 Фазы 2–6** (React Native).
В песочнице для внешних блоков делать нечего — они выполняются владельцем на staging
по готовым инструкциям. Долг `tests-block14` 29/32 (сверка снапшота с живой БД) закрыт
12.09.2026: тест брал `data/shop.db` вместо БД сервера (`MAGAZIN_DB`), из-за чего при
изолированном прогоне снапшот и «живая» база были разными файлами — 3 ложных падения.
Теперь тест читает тот же `MAGAZIN_DB`, что и сервер, и подключён к `run-tests.sh`/CI.
**Мобильные приложения (08.09.2026):** складское APK готово (Sklad-1.0.6,
`ru.telegramshop.sklad`); покупательское — НЕТ (болванка в `mobile/`, сборке не
подлежит). Подготовлены ТЗ и план: **блок 25** + `mobile/ANDROID-APP-TZ.md`
(Фаза 1 — WebView-обёртка за 1–2 дня, Фазы 2–6 — React Native за 4–5 недель).

**Складской APK 1.1.0 (09.09.2026, блок 26):** по решению владельца — только
склад, без покупательского и без сторов. Нативные фичи обёртки: сохранение
файлов в «Загрузки», печать этикеток с телефона по Wi-Fi (:9100 ZPL/EPL),
«экран не гаснет», вибро на скан, экран ошибки с «Повторить», приём сканов от
ТСД (`sklad://scan?code=`). APK собран и доставлен в репо через CI
(GitHub Actions, run-tests → ci-build-apk: 2.6M, versionCode 8, подпись как у
1.0.6); сервер раздаёт 1.1.0 через `/apk/`, `/download/android`,
`/api/releases/android` — встроенный update-check предложит обновление.

**Порядок приоритета:** после инфраструктурных блоков 13–15 выполнять блоки 20 (SEO/продвижение), 21 (Content Hub и AI prompt queue), затем 22 (Wildberries), 23–24. Ручной блок 17 выполняется на staging параллельно, а автодеплой финализируется последним.

| 17 | Ручная production-валидация и перенос тяжёлых проверок | ⏳ | 12–16 | `DEVELOPER-MANUAL-VALIDATION.md` |

| 18 | Backup/restore production на тестовом VPS | ⏳ | 14, 17 | `blocks/BLOCK-18-backup-production.md` |
| 19 | Внутренняя CRM и общение сотрудников | ✅ | 08.09.2026 | `blocks/BLOCK-19-internal-crm.md` |

| 20 | SEO и продвижение: Yandex, Google, Instagram, VK, TikTok, Telegram | ✅ | 08.09.2026 | `blocks/BLOCK-20-seo-promotion.md` |

| 21 | AI-генерация видео и контент-агенты для соцсетей | ✅ | 08.09.2026 | `blocks/BLOCK-21-ai-video-content.md` |
| 22 | Wildberries: ресейл и интеграция marketplace | ⛔ | 13, 20 | `blocks/BLOCK-22-wildberries-resale.md` |

| 23 | Content Hub и AI Video Queue | ✅ | 08.09.2026 | `blocks/BLOCK-23-content-hub-ai-queue.md` |
| 24 | Campaign Manager и публикация по каналам | ✅ | 08.09.2026 | `blocks/BLOCK-24-campaign-manager.md` |
| 25 | Мобильное приложение покупателя (Android) | 🔨 Фаза 1 ✅ 11.09.2026; Фазы 2–6 ⏳ | — (Ф1); 15 (Ф2+) | `blocks/BLOCK-25-mobile-buyer-app.md` · ТЗ: `mobile/ANDROID-APP-TZ.md` |
| 26 | Складской APK 1.1.0: нативные возможности | ✅ | 09.09.2026 | `blocks/BLOCK-26-sklad-apk-native.md` |
| 27 | CSP-закалка: вынос inline-JS, Content-Security-Policy | ✅ | 11.09.2026 | `blocks/BLOCK-27-csp-hardening.md` |
| 28 | Установка «из коробки»: setup.sh, мастер .env, setup_bot, build-apps, update, bootstrap VPS | ✅ | 12.09.2026 | `blocks/BLOCK-28-autosetup.md` · инструкция: `SETUP-AUTO.md` |

### Текущий прогресс (11.09.2026) — кодовые блоки закрыты, Фаза 1 покупательского APK готова

- Закрыты блоки: 09, 13, 14, 15, 16, 19, 20, 21, 23, 24, 26, **27 (CSP)**;
  **25 Фаза 1** (покупательский APK-обёртка) — отчёты в файлах блоков.
- Блок 22 — ⛔ внешнее условие (официальный API-аудит Wildberries); boundary и
  диагностика готовы и протестированы.
- Ручные на staging: 11 (железо), 17 (manual validation checklist), 18 (backup на тестовом VPS).
- Автотесты: ~480 проверок в 13 test-suite'ах + pytest (35, в run-tests.sh/CI с 12.09.2026); порядок регрессии см. выше (block15 — последним).
- `tests-block14` (32/32) в порядке регрессии после block09 и в `run-tests.sh` — долг закрыт 12.09.2026.
